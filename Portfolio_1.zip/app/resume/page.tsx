import React from 'react'

function ResumePage() {
  return (
    <div>ResumePage</div>
  )
}

export default ResumePage